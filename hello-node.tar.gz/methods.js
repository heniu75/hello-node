var methods = {};

methods.updateServer = function(){
  console.log('updating server...');
}

methods.eatCookies = function(){
  console.log('eating cookies...');
}

methods.sayHi = function(){
  console.log('NodeJS is awesome!');
}

exports.myMethods = methods;
