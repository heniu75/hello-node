console.log('hello world!');

for(i=0; i<10; ++i)
{
	console.log('Hello ' + i.toString());
}

var x = Math.pow(2,2);

console.log(x);
